import java.util.ArrayList;
import java.util.Iterator;
public abstract class OrderedDataStructure<T> implements Iterable<T> {

    private int size;

    public OrderedDataStructure() {
        size = 0;
    }

    public OrderedDataStructure(ArrayList<T> index) {
        for (T value : index) {
            add(value);
        }
    }

    public synchronized int getSize() {
        return size;
    }

    public synchronized ArrayList<T> toArrayList() {
        ArrayList<T> list = new ArrayList<T>();
        for (T value : this) {
            list.add(value);
        }
        return list;
    }

    public synchronized String toString() {
        String list = "";
        for (T value : this) {
            list += value + " ";
        }
        return list;
    }

    public abstract T get(int index);

    public abstract int add(T value);

    @Override
    public abstract Iterator<T> iterator();
}