import java.util.Iterator;
import java.util.NoSuchElementException;

public class DoubleLinkedList<T> extends OrderedDataStructure<T>{
	private DoubleLinkedListNode<T> header;

	private static class DoubleLinkedListNode<T> {
		private T value;
		private DoubleLinkedListNode<T> next;
		private DoubleLinkedListNode<T> prev;
		
		public DoubleLinkedListNode(T value, DoubleLinkedListNode<T> next, DoubleLinkedListNode<T> prev) {
			this.value = value;
			this.next = next;
			this.prev = prev;
		}
		public T getValue() {
			return value;
		}
		public DoubleLinkedListNode<T> getNext() {
			return next;
		}
		public DoubleLinkedListNode<T> getPrev(){
			return prev;
		}
		public void setNext(DoubleLinkedListNode<T> next) {
			this.next = next;
		}
	}

	
	public DoubleLinkedList() {
		header = null;
	}

	public synchronized int getSize() {
		int index = 0;
		if (header == null) {
			return index;
		}
		else {
			DoubleLinkedListNode<T> currentNode = header;
			while (currentNode != null) {
				index++;
				currentNode = currentNode.getNext();
			}
			return index;
		}
	}
	
	public synchronized T get(int index) {
		if (header == null || index < 0) {
			return null;
		}
		else if (index == 0) {
			T rtnValue = header.getValue();
			return rtnValue;
		}
		else {
			DoubleLinkedListNode<T> currentNode = header;
			int currentIndex = 1;
			while (currentIndex < index && currentNode != null) {
				currentIndex++;
				currentNode = currentNode.getNext();
			}
			if (currentIndex == index && currentNode.getNext() != null) {
				DoubleLinkedListNode<T> nextNode = currentNode.getNext();
				T rtnValue = nextNode.getValue();
				currentNode.setNext(nextNode.getNext());
				return rtnValue;
			}
			else {
				return null;
			}
		}
	}

	public synchronized int insert(T value, int index) {
		int currentIndex = 0;
		if (header == null) {
			header = new DoubleLinkedListNode<T>(value, null, null);
		}
		else if (index <= 0) {
			header = new DoubleLinkedListNode<T>(value, header, null);
		}
		else {
			DoubleLinkedListNode<T> currentNode = header;
			
			currentIndex++;
			while (currentIndex < index && currentNode != null) {
				currentIndex++;
				currentNode = currentNode.getNext();
			}
			DoubleLinkedListNode<T> insertedNode = new DoubleLinkedListNode<T>(value, currentNode.getNext(), currentNode.getPrev());
			currentNode.setNext(insertedNode);
		}
		return currentIndex;
	}
	
	public synchronized int add(T value) {
		insert(value, getSize());
		return getSize();
	}
	
	public synchronized T remove(int index) {
		if (header == null || index < 0) {
			return null;
		}
		else if (index <= 0) {
			T rtnValue = header.getValue();
			header = header.getNext();
			return rtnValue;
		}
		else {
			DoubleLinkedListNode<T> currentNode = header;
			int currentIndex = 1;
			while(currentIndex < index && currentNode.getNext() != null) {
				currentIndex++;
				currentNode = currentNode.getNext();
			}
			if (currentIndex == index && currentNode.getNext() == null) {
				DoubleLinkedListNode<T> nextNode = currentNode.getNext();
				T rtnValue = currentNode.getNext().getValue();
				currentNode.setNext(nextNode.getNext());
				return rtnValue;
			}
			else {
				return null;
			}

		}
	}

//	public String toString() {
//		if (header == null) {
//			return "List is empty";
//		}
//		else {
//			String rtn = "";
//			DoubleLinkedListNode<T> current = header;
//			while (current != null) {
//				rtn += current.getValue()+", ";
//				current = current.getNext();
//			}
//			return rtn;
//		}
//	}
	
	public synchronized String toStringRecursion() {
		if (header == null) {
			return "List is empty";
		}
		else {
			return Recursion(header);
		}
	}
	private synchronized String Recursion(DoubleLinkedListNode<T> currentNode) {
		if (currentNode == null) {
			return "";
		}
		else {
			return currentNode.getValue()+", "+Recursion(currentNode.getNext());
		}
	}

	@Override
    public synchronized Iterator<T> iterator() {
        return new Iterator<T>() {
            private DoubleLinkedListNode<T> current = header;

            public boolean hasNext() {
                return current != null;
            }

            public T next() {
                if (!hasNext()) {
                    throw new NoSuchElementException();
                }
                T value = current.getValue();
                current = current.next;
                return value;
            }

            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }
}
