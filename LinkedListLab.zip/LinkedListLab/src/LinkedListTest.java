import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import java.util.ArrayList;
import org.junit.Before;

class LinkedListTest {

	private LinkedList<Integer> list;

	@Before
	public void setUp() {
		list = new LinkedList<Integer>();
		list.add(5);
		list.add(3);
		list.add(7);
		list.add(1);
		list.add(9);
	}

	@Test
	public void testGetSize() {
		assertEquals(5, list.getSize());
	}

	@Test
	public void testGet() {
		assertEquals((Integer) 1, list.get(0));
		assertEquals((Integer) 3, list.get(1));
		assertEquals((Integer) 5, list.get(2));
		assertEquals((Integer) 7, list.get(3));
		assertEquals((Integer) 9, list.get(4));
	}

	@Test
	public void testAdd() {
		list.add(4);
		assertEquals(6, list.getSize());
		assertEquals((Integer) 4, list.get(1));
	}
	
	@Test
	public void testInsert() {
		list.insert(5, 0);
		assertEquals((Integer) 6, list.getSize());
	}
	
	@Test
	public void testRemove() {
		assertEquals((Integer) 4, list.remove(1));
	}

	@Test
	public void testToArrayList() {
		ArrayList<Integer> expected = new ArrayList<Integer>();
		expected.add(1);
		expected.add(3);
		expected.add(5);
		expected.add(7);
		expected.add(9);
		assertTrue(expected.equals(list.toArrayList()));
	}

	@Test
	public void testIterator() {
		ArrayList<Integer> expected = new ArrayList<Integer>();
		expected.add(1);
		expected.add(3);
		expected.add(5);
		expected.add(7);
		expected.add(9);
		int i = 0;
		for (Integer value : list) {
			assertEquals(expected.get(i), value);
			i++;
		}
	}
}
