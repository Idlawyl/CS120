import java.util.Random;
import java.util.Scanner;

public class Syncronized_Queue<T> {
	private QueueNode<T> header;
	public static final Syncronized_Queue<Integer> queue = new Syncronized_Queue<>();

	private static class QueueNode<T>{
		private T value;
		private QueueNode<T> next;
		public QueueNode(T value, QueueNode<T> next, QueueNode<T> prev) {
			this.value = value;
			this.next = next;
		}
		public T getValue() {
			return value;
		}
		public QueueNode<T> getNext() {
			return next;
		}
		public void setNext(QueueNode<T> next) {
			this.next = next;
		}
	}

	public Syncronized_Queue() {
		header = null;
	}

	public synchronized void push(T value) {
		if (header == null) {
			header = new QueueNode<T>(value, null, null);
		}
		else {
			header = new QueueNode<T>(value, header, null);
		}
	}

	public synchronized int getSize() {
		int index = 0;
		if (header == null) {
			return index;
		}
		else {
			QueueNode<T> currentNode = header;
			while (currentNode != null) {
				index++;
				currentNode = currentNode.getNext();
			}
			return index;
		}
	}

	public synchronized T remove(int index) {
		if (header == null || index < 0) {
			return null;
		}
		else if (index == 0) {
			T rtnValue = header.getValue();
			return rtnValue;
		}
		else {
			QueueNode<T> currentNode = header;
			int currentIndex = 1;
			while (currentIndex < index && currentNode != null) {
				currentIndex++;
				currentNode = currentNode.getNext();
			}
			if (currentIndex == index && currentNode.getNext() != null) {
				QueueNode<T> nextNode = currentNode.getNext();
				T rtnValue = nextNode.getValue();
				currentNode.setNext(nextNode.getNext());
				return rtnValue;
			}
			else {
				return null;
			}
		}
	}

	private synchronized T get(int index) {
		if (header == null || index < 0) {
			return null;
		}
		else if (index == 0) {
			T rtnValue = header.getValue();
			return rtnValue;
		}
		else {
			QueueNode<T> currentNode = header;
			int currentIndex = 1;
			while (currentIndex < index && currentNode != null) {
				currentIndex++;
				currentNode = currentNode.getNext();
			}
			if (currentIndex == index && currentNode.getNext() != null) {
				QueueNode<T> nextNode = currentNode.getNext();
				T rtnValue = nextNode.getValue();
				return rtnValue;
			}
			else {
				return null;
			}
		}
	}

	public synchronized T pop() {
		if(header == null) {
			return null;
		}
		else {
			T currentValue = remove(getSize()-1);
			return currentValue;
		}
	}

	public synchronized T top() {
		if(header == null) {
			return null;
		}
		else {
			T currentValue = get(getSize()-1);
			return currentValue;
		}
	}

	public synchronized String toString() {
		if (header == null) {
			return "List is empty";
		}
		else {
			String rtn = "";
			QueueNode<T> current = header;
			while (current != null) {
				rtn += current.getValue()+", ";
				current = current.getNext();
			}
			return rtn;
		}
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Size of the queue: ");
		int queueSize = scanner.nextInt();

		System.out.print("Number of producer threads: ");
		int ProducerThreads = scanner.nextInt();

		System.out.print("Number of consumer threads: ");
		int ConsumerThreads = scanner.nextInt();

		System.out.print("Delay between each item produced: ");
		int produceDelay = scanner.nextInt();

		System.out.print("Delay between each item consumed: ");
		int consumeDelay = scanner.nextInt();
		scanner.close();

		for (int i = 0; i < ProducerThreads; i++) {
			Thread producer = new Thread(new Producer(produceDelay, queueSize, queue));
			producer.start();
		}

		for (int i = 0; i < ConsumerThreads; i++) {
			Thread consumer = new Thread(new Consumer(consumeDelay, queue));
			consumer.start();
		}
	}
}

class Producer implements Runnable{
	private int produceDelay;
	private Syncronized_Queue<Integer> queue;
	private int queueSize;
	public Producer(int produceDelay, int queueSize, Syncronized_Queue<Integer> queue) {
		this.produceDelay = produceDelay;
		this.queueSize = queueSize;
		this.queue = queue;
	}
	@Override
	public void run() {
		while (true) {
			try {
				Thread.sleep(produceDelay);
				synchronized (queue) {
					if (queue.getSize() < queueSize) {
						Random random = new Random();
						int value = random.nextInt(300);
						queue.push(value);
						System.out.println("Value Added: " + value);
					}
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}

class Consumer implements Runnable {
	private int consumeDelay;
	private Syncronized_Queue<Integer> queue;

	public Consumer(int consumeDelay, Syncronized_Queue<Integer> queue) {
		this.consumeDelay = consumeDelay;
		this.queue = queue;
	}

	@Override
	public void run() {
		while (true) {
			try {
				Thread.sleep(consumeDelay);
				synchronized (queue) {
					if (queue.getSize() != 0) {
						int value = queue.remove(0);
						System.out.println("Value Removed:" + value);
					}
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}