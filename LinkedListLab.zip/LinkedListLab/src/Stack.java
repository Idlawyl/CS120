public class Stack<T> {
	private StackNode<T> header;
	
	private static class StackNode<T> {
		private T value;
		private StackNode<T> next;
		
		public StackNode(T value, StackNode<T> next) {
			this.value = value;
			this.next = next;
		}
		public T getValue() {
			return value;
		}
		public StackNode<T> getNext() {
			return next;
		}
	}
	public Stack() {
		header = null;
	}
	
	public synchronized void push(T value) {
		if (header == null) {
			header = new StackNode<T>(value, null);
		}
		else {
			header = new StackNode<T>(value, header);
		}
	}
	
	public synchronized T pop() {
		if(header == null) {
			return null;
		}
		else {
			T currentValue = header.getValue();
			header = header.getNext();
			return currentValue;
		}
	}
	
	public synchronized T top() {
		if(header == null) {
			return null;
		}
		else {
			T currentValue = header.getValue();
			return currentValue;
		}
	}
	
	public synchronized String toString() {
		if (header == null) {
			return "List is empty";
		}
		else {
			String rtn = "";
			StackNode<T> current = header;
			while (current != null) {
				rtn += current.getValue()+", ";
				current = current.getNext();
			}
			return rtn;
		}
	}
}