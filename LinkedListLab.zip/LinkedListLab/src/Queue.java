public class Queue<T> {
	private QueueNode<T> header;
	
	private static class QueueNode<T>{
		private T value;
		private QueueNode<T> next;
		public QueueNode(T value, QueueNode<T> next, QueueNode<T> prev) {
			this.value = value;
			this.next = next;
		}
		public T getValue() {
			return value;
		}
		public QueueNode<T> getNext() {
			return next;
		}
		public void setNext(QueueNode<T> next) {
			this.next = next;
		}
	}
	
	public Queue() {
		header = null;
	}
	
	public synchronized void push(T value) {
		if (header == null) {
			header = new QueueNode<T>(value, null, null);
		}
		else {
			header = new QueueNode<T>(value, header, null);
		}
	}
	
	public synchronized int getSize() {
		int index = 0;
		if (header == null) {
			return index;
		}
		else {
			QueueNode<T> currentNode = header;
			while (currentNode != null) {
				index++;
				currentNode = currentNode.getNext();
			}
			return index;
		}
	}
	
	private synchronized T remove(int index) {
		if (header == null || index < 0) {
			return null;
		}
		else if (index == 0) {
			T rtnValue = header.getValue();
			return rtnValue;
		}
		else {
			QueueNode<T> currentNode = header;
			int currentIndex = 1;
			while (currentIndex < index && currentNode != null) {
				currentIndex++;
				currentNode = currentNode.getNext();
			}
			if (currentIndex == index && currentNode.getNext() != null) {
				QueueNode<T> nextNode = currentNode.getNext();
				T rtnValue = nextNode.getValue();
				currentNode.setNext(nextNode.getNext());
				return rtnValue;
			}
			else {
				return null;
			}
		}
	}
	
	private synchronized T get(int index) {
		if (header == null || index < 0) {
			return null;
		}
		else if (index == 0) {
			T rtnValue = header.getValue();
			return rtnValue;
		}
		else {
			QueueNode<T> currentNode = header;
			int currentIndex = 1;
			while (currentIndex < index && currentNode != null) {
				currentIndex++;
				currentNode = currentNode.getNext();
			}
			if (currentIndex == index && currentNode.getNext() != null) {
				QueueNode<T> nextNode = currentNode.getNext();
				T rtnValue = nextNode.getValue();
				return rtnValue;
			}
			else {
				return null;
			}
		}
	}
	
	public synchronized T pop() {
		if(header == null) {
			return null;
		}
		else {
			T currentValue = remove(getSize()-1);
			return currentValue;
		}
	}
	
	public synchronized T top() {
		if(header == null) {
			return null;
		}
		else {
			T currentValue = get(getSize()-1);
			return currentValue;
		}
	}
	
	public synchronized String toString() {
		if (header == null) {
			return "List is empty";
		}
		else {
			String rtn = "";
			QueueNode<T> current = header;
			while (current != null) {
				rtn += current.getValue()+", ";
				current = current.getNext();
			}
			return rtn;
		}
	}
}
