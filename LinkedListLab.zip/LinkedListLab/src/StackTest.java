import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.jupiter.api.Test;

class StackTest {

	private Stack<Integer> list;

	@Before
	public void setUp() {
		list = new Stack<Integer>();
		list.push(5);
		list.push(3);
		list.push(7);
		list.push(1);
		list.push(9);
	}

	@Test
	public void testTop() {
		assertEquals((Integer) 5, list.top());
	}
	
	@Test
	public void testPop() {
		assertEquals((Integer) 5, list.pop());
		assertEquals((Integer) 3, list.pop());
		assertEquals((Integer) 7, list.pop());
	}
}
