import java.util.Iterator;
import java.util.NoSuchElementException;

public class SortedLinkedList<T extends Comparable <T>> extends OrderedDataStructure<T> {
	private SortedLinkedListNode<T> header;

	private static class SortedLinkedListNode<T> {
		private T value;
		private SortedLinkedListNode<T> next;

		public SortedLinkedListNode(T value, SortedLinkedListNode<T> next) {
			this.value = value;
			this.next = next;
		}
		public T getValue() {
			return value;
		}
		public SortedLinkedListNode<T> getNext() {
			return next;
		}
		public void setNext(SortedLinkedListNode<T> next) {
			this.next = next;
		}

	}


	public SortedLinkedList() {
		header = null;
	}

	public synchronized int add(T value) {
		SortedLinkedListNode<T> currentNode = header;
		SortedLinkedListNode<T> newNode = new SortedLinkedListNode<T>(value, header);
		int index = 0;

		if (header == null) {
			header = new SortedLinkedListNode<T>(value, null);
			return 0;
		}

		if (header.getValue().compareTo(value) > 0) {
			header = new SortedLinkedListNode<T>(value, header);
			return 0;
		}

		while(currentNode.getNext() != null && currentNode.getNext().getValue().compareTo(value) <= 0) {
			currentNode = currentNode.getNext();
			index++;
		}
		newNode.setNext(currentNode.getNext());
		currentNode.setNext(newNode);

		return index+1;
	}

	public synchronized int getSize() {
		int index = 0;
		if (header == null) {
			return index;
		}
		else {
			SortedLinkedListNode<T> currentNode = header;
			while (currentNode != null) {
				index++;
				currentNode = currentNode.getNext();
			}
			return index;
		}
	}

	public synchronized T get(int index) {
		if (header == null || index < 0) {
			return null;
		}
		else if (index == 0) {
			T rtnValue = header.getValue();
			return rtnValue;
		}
		else {
			SortedLinkedListNode<T> currentNode = header;
			int currentIndex = 1;
			while (currentIndex < index && currentNode != null) {
				currentIndex++;
				currentNode = currentNode.getNext();
			}
			if (currentIndex == index && currentNode.getNext() != null) {
				SortedLinkedListNode<T> nextNode = currentNode.getNext();
				T rtnValue = nextNode.getValue();
				currentNode.setNext(nextNode.getNext());
				return rtnValue;
			}
			else {
				return null;
			}
		}
	}

	public synchronized T remove(int index) {
		if (header == null || index < 0) {
			return null;
		}
		else if (index <= 0) {
			T rtnValue = header.getValue();
			header = header.getNext();
			return rtnValue;
		}
		else {
			SortedLinkedListNode<T> currentNode = header;
			int currentIndex = 1;
			while(currentIndex < index && currentNode.getNext() != null) {
				currentIndex++;
				currentNode = currentNode.getNext();
			}
			if (currentIndex == index && currentNode.getNext() == null) {
				SortedLinkedListNode<T> nextNode = currentNode.getNext();
				T rtnValue = currentNode.getNext().getValue();
				currentNode.setNext(nextNode.getNext());
				return rtnValue;
			}
			else {
				return null;
			}

		}
	}

	public synchronized T getValue(T value) {
		if (header == null) {
			return null;
		}
		else {
			SortedLinkedListNode<T> currentNode = header;
			int currentIndex = 1;
			while(currentIndex < getSize() && currentNode.getNext() != null) {
				currentIndex++;
				if (value == currentNode.getValue()) {
					return value;
				}
				currentNode = currentNode.getNext();
			}
		}
		return null;
	}

//	public String toString() {
//		if (header == null) {
//			return "List is empty";
//		}
//		else {
//			String rtn = "";
//			SortedLinkedListNode<T> current = header;
//			while (current != null) {
//				rtn += current.getValue()+", ";
//				current = current.getNext();
//			}
//			return rtn;
//		}
//	}

	public synchronized String toStringRecursion() {
		if (header == null) {
			return "List is empty";
		}
		else {
			return Recursion(header);
		}
	}
	private synchronized String Recursion(SortedLinkedListNode<T> currentNode) {
		if (currentNode == null) {
			return "";
		}
		else {
			return currentNode.getValue()+", "+Recursion(currentNode.getNext());
		}
	}
	
	@Override
    public Iterator<T> iterator() {
        return new Iterator<T>() {
            private SortedLinkedListNode<T> current = header;

            public boolean hasNext() {
                return current != null;
            }

            public T next() {
                if (!hasNext()) {
                    throw new NoSuchElementException();
                }
                T value = current.getValue();
                current = current.next;
                return value;
            }

            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }
}
