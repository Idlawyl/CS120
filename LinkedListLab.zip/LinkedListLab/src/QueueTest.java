import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.Before;

class QueueTest {

	private Queue<Integer> list;

	@Before
	public void setUp() {
		list = new Queue<Integer>();
		list.push(5);
		list.push(3);
		list.push(7);
		list.push(1);
		list.push(9);
	}

	
	
	@Test
	public void testGetSize() {
		assertEquals(5, list.getSize());
	}

	@Test
	public void testPush() {
		list.push(4);
		list.push(5);
		list.push(7);
		assertEquals(7, list.getSize());
	}
	
	@Test
	public void testTop() {
		assertEquals((Integer) 5, list.top());
	}
	
	@Test
	public void testPop() {
		assertEquals((Integer) 5, list.pop());
		assertEquals((Integer) 3, list.pop());
		assertEquals((Integer) 7, list.pop());
	}
}