import java.util.Iterator;
import java.util.NoSuchElementException;

public class LinkedList<T> extends OrderedDataStructure<T>{
	private LinkedListNode<T> header;

	private static class LinkedListNode<T> {
		private T value;
		private LinkedListNode<T> next;

		public LinkedListNode(T value, LinkedListNode<T> next) {
			this.value = value;
			this.next = next;
		}
		public T getValue() {
			return value;
		}
		public LinkedListNode<T> getNext() {
			return next;
		}
		public void setNext(LinkedListNode<T> next) {
			this.next = next;
		}

	}

	public LinkedList() {
		header = null;
	}

	public synchronized int getSize() {
		int index = 0;
		if (header == null) {
			return index;
		}
		else {
			LinkedListNode<T> currentNode = header;
			while (currentNode != null) {
				index++;
				currentNode = currentNode.getNext();
			}
			return index;
		}
	}

	public synchronized T get(int index) {
		if (header == null || index < 0) {
			return null;
		}
		else if (index == 0) {
			T rtnValue = header.getValue();
			return rtnValue;
		}
		else {
			LinkedListNode<T> currentNode = header;
			int currentIndex = 1;
			while (currentIndex < index && currentNode != null) {
				currentIndex++;
				currentNode = currentNode.getNext();
			}
			if (currentIndex == index && currentNode.getNext() != null) {
				LinkedListNode<T> nextNode = currentNode.getNext();
				T rtnValue = nextNode.getValue();
				currentNode.setNext(nextNode.getNext());
				return rtnValue;
			}
			else {
				return null;
			}
		}
	}

	public synchronized int insert(T value, int index) {
		int currentIndex = 0;
		if (header == null) {
			header = new LinkedListNode<T>(value, null);
		}
		else if (index <= 0) {
			header = new LinkedListNode<T>(value, header);
		}
		else {
			LinkedListNode<T> currentNode = header;
			currentIndex++;
			while (currentIndex < index && currentNode != null) {
				currentIndex++;
				currentNode = currentNode.getNext();
			}
			LinkedListNode<T> insertedNode = new LinkedListNode<T>(value, currentNode.getNext());
			currentNode.setNext(insertedNode);
		}
		return currentIndex;
	}

	public synchronized int add(T value) {
		insert(value, getSize());
		return getSize();
	}

	public synchronized T remove(int index) {
		if (header == null || index < 0) {
			return null;
		}
		else if (index <= 0) {
			T rtnValue = header.getValue();
			header = header.getNext();
			return rtnValue;
		}
		else {
			LinkedListNode<T> currentNode = header;
			int currentIndex = 1;
			while(currentIndex < index && currentNode.getNext() != null) {
				currentIndex++;
				currentNode = currentNode.getNext();
			}
			if (currentIndex == index && currentNode.getNext() == null) {
				LinkedListNode<T> nextNode = currentNode.getNext();
				T rtnValue = currentNode.getNext().getValue();
				currentNode.setNext(nextNode.getNext());
				return rtnValue;
			}
			else {
				return null;
			}

		}
	}
//	public String toString() {
//		if (header == null) {
//			return "List is empty";
//		}
//		else {
//			String rtn = "";
//			LinkedListNode<T> current = header;
//			while (current != null) {
//				rtn += current.getValue()+", ";
//				current = current.getNext();
//			}
//			return rtn;
//		}
//	}

	public synchronized String toStringRecursion() {
		if (header == null) {
			return "List is empty";
		}
		else {
			return Recursion(header);
		}
	}
	private synchronized String Recursion(LinkedListNode<T> currentNode) {
		if (currentNode == null) {
			return "";
		}
		else {
			return currentNode.getValue()+", "+Recursion(currentNode.getNext());
		}
	}
	
	 @Override
	    public Iterator<T> iterator() {
	        return new Iterator<T>() {
	            private LinkedListNode<T> current = header;

	            public boolean hasNext() {
	                return current != null;
	            }

	            public T next() {
	                if (!hasNext()) {
	                    throw new NoSuchElementException();
	                }
	                T value = current.getValue();
	                current = current.next;
	                return value;
	            }

	            public void remove() {
	                throw new UnsupportedOperationException();
	            }
	        };
	    }

}