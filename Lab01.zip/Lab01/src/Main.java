import HashTables.LinearProbingHashTable;
import HashTables.StandardHashTable;

public class Main {
    public static void main(String[] args) {
        StandardHashTable standardHashTable = new StandardHashTable(10);

        standardHashTable.insert(1, 100);
        standardHashTable.insert(2, 200);
        standardHashTable.insert(11, 1100);

        System.out.println("Key 1: " + standardHashTable.get(1)); // Output: 100
        System.out.println("Key 2: " + standardHashTable.get(2)); // Output: 200
        System.out.println("Key 11: " + standardHashTable.get(11)); // Output: 1100

        standardHashTable.delete(2);
        System.out.println("Key 2 after deletion: " + standardHashTable.get(2)); // Output: -1 (not found)

        LinearProbingHashTable linearProbingHashTable = new LinearProbingHashTable(10);

        linearProbingHashTable.linearInsert(1, 100);
        linearProbingHashTable.linearInsert(1, 200);
        linearProbingHashTable.linearInsert(2, 300);
        linearProbingHashTable.linearInsert(8, 400);

        System.out.println("Key 1: " + linearProbingHashTable.linearGet(1)); // Output: 100
        System.out.println("Key 2: " + linearProbingHashTable.linearGet(2)); // Output: 200
        System.out.println("Key 3: " + linearProbingHashTable.linearGet(3)); // Output: 300
        System.out.println("Key 8: " + linearProbingHashTable.linearGet(8)); // Output: 400
    }
}