package HashTables;

import java.util.ArrayList;

public class StandardHashTable {
    private ArrayList<Integer>[] table;
    private int n;

    public StandardHashTable(int n){
        this.n = n;
        table = new ArrayList[n];
        for(int i = 0; i < n; i++){
            table[i] = new ArrayList<>();
        }
    }

    private int hash(int key){
        return key % n;
    }

    public void insert(int key, int value){
        int index = hash(key);
        ArrayList<Integer> pairArray = table[index];
        pairArray.add(key);
        pairArray.add(value);
    }
    public int get(int key) {
        int index = hash(key);
        ArrayList<Integer> pairArray = table[index];
        for (int i = 0; i < pairArray.size(); i += 2) {
            if (pairArray.get(i) == key) {
                return pairArray.get(i+1);
            }
        }
        return -1;
    }
    public void delete(int key){
        int index = hash(key);
        ArrayList<Integer> pairArray = table[index];
        pairArray.remove(0);
        pairArray.remove(0);
    }
}
