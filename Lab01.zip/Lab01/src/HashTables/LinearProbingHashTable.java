package HashTables;

import java.util.ArrayList;

public class LinearProbingHashTable {
    private ArrayList<Integer>[] table;
    private int n;

    public LinearProbingHashTable(int n){
        this.n = n;
        table = new ArrayList[n];
        for(int i = 0; i < n; i++){
            table[i] = new ArrayList<>();
        }
    }
    private int hash(int key){
        return key % n;
    }

    public void linearInsert(int key, int value){
        for (int i = hash(key); i < n; i++){
            ArrayList<Integer> pairArray = table[i];
            if(pairArray.isEmpty()) {
                pairArray.add(key);
                pairArray.add(value);
                return;
            }
        }
    }

    public int linearGet(int key) {
        ArrayList<Integer> pairArray = table[hash(key)];
        if(pairArray.isEmpty()){
            return -1;
        }
        else {
            return pairArray.get(1);
        }
    }
}
