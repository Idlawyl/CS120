package tests;
import HashTables.LinearProbingHashTable;
import HashTables.StandardHashTable;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.BeforeClass;
public class testing{
    public StandardHashTable standardHashTable;
    public LinearProbingHashTable linearProbingHashTable;
    @Before
    public void setUpStandard() throws Exception {
        standardHashTable = new StandardHashTable(10);
        standardHashTable.insert(1, 100);
        standardHashTable.insert(2, 200);
        standardHashTable.insert(3, 1100);
    }
    @Test
    public void insertTestStandard() throws Exception{
        standardHashTable.insert(4, 400);
        assertEquals(400, standardHashTable.get(4));
    }
    @Test
    public void getTestStandard() throws Exception{
        assertEquals(100, standardHashTable.get(1));
    }
    @Test
    public void deleteTest() throws Exception{
        standardHashTable.delete(1);
        assertEquals(-1, standardHashTable.get(1));
    }

    @Before
    public void setUpLinear() throws Exception {
        linearProbingHashTable = new LinearProbingHashTable(10);
        linearProbingHashTable.linearInsert(8, 400);
    }
    @Test
    public void insertTest() throws Exception{
        linearProbingHashTable.linearInsert(1, 100);
        linearProbingHashTable.linearInsert(1, 200);
        linearProbingHashTable.linearInsert(2, 300);
        assertEquals(100, linearProbingHashTable.linearGet(1));
        assertEquals(200, linearProbingHashTable.linearGet(2));
        assertEquals(300, linearProbingHashTable.linearGet(3));
    }
    @Test
    public void getTest() throws Exception {
        assertEquals(400, linearProbingHashTable.linearGet(8));
    }
}