import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
class TwoThreeTest {

    class TwoThreeTestTree extends TwoThree{
        public TwoThreeTestTree(int value, TwoThree child1, TwoThree child2) {
            super(value, child1, child2);
        }

        @Override
        public boolean isMalformed() {
            return super.isMalformed();
        }
        @Override
        public TwoThree FourtoThreeTwoNode() {
            return super.FourtoThreeTwoNode();
        }
        @Override
        public InnerReturnClass FourNodetoTwoTwoNode() {
            return super.FourNodetoTwoTwoNode();
        }
        class InnerReturnClassExtension extends InnerReturnClass{

        }
    }

    @Test
    void setters() throws Exception{
        //If these work, all setters work.
        TwoThree root = new TwoThree(10, null, null);
        root.setChild1(new TwoThree(9, null, null));
        root.setChild2(new TwoThree(11, null, null));
        assertEquals(root.child1.value1, 9);
        assertEquals(root.child2.value1, 11);
    }

    @Test
    void isTwoNodeTest() throws Exception{
        TwoThree root = new TwoThree(10, null, null);
        assertTrue(root.isTwoNode());
    }

    @Test
    void isMalformedTest() throws Exception{
        TwoThree root = new TwoThree(10, null, null);
        TwoThree invalidNode = new TwoThree(0, null, null);
        assertTrue(invalidNode.isMalformed());
        assertFalse(root.isMalformed());
    }

    @Test
    void searchContainmentTest() throws Exception{
        //If test is accurate, all search functions are working correctly
        TwoThree root = new TwoThree(9, null, null);
        root.setChild1(new TwoThree(5, null, null));
        root.setChild2(new TwoThree(13, null, null));
        assertTrue(root.searchContainment(9, root));
        assertFalse(root.searchContainment(23, root));
    }

    @Test
    void insertTest() throws Exception{
        TwoThree root = new TwoThree(10, null, null);
        root.insert(7, root);
        assertTrue(root.value1 == 7);
    }

    @Test
    void getMaxTest() throws Exception{
        TwoThree root = new TwoThree(10, null, null);
        root.setChild2(new TwoThree(17, null, null));
        assertEquals(root.getMax(root), 17);
    }

    @Test
    void displayInOrderTest() throws Exception{
        TwoThree root = new TwoThree(10, null, null);
        root.setChild1(new TwoThree(7, null, null));
        root.setChild2(new TwoThree(17, null, null));

        assertEquals("7, 10, 17, ", root.displayInOrder(root));
    }
}
