public class TwoThree{
    int value1;
    int value2;
    int tempValue3;
    TwoThree root;
    TwoThree parent;
    TwoThree child1;
    TwoThree child2;
    TwoThree child3;
    TwoThree tempChild4;

    public void setValue1(int value1) {
        this.value1 = value1;
    }
    public void setValue2(int value2) {
        this.value2 = value2;
    }
    public void setChild1(TwoThree child1) {
        this.child1 = child1;
    }
    public void setChild2(TwoThree child2) {
        this.child2 = child2;
    }
    public void setChild3(TwoThree child3){
        this.child3 = child3;
    }
    public TwoThree(int value, TwoThree child1, TwoThree child2){
        //TwoNode Values
        parent = null;
        this.value1 = value;
        this.child1 = child1;
        this.child2 = child2;
        //ThreeNode Values
        value2 = 0;
        child3 = null;
        //Temporary FourNode Values
        tempValue3 = 0;
        tempChild4 = null;
    }
    boolean isTwoNode(){
        if(value2==0 && child3==null){
            return true;
        }
        else{
            if (!(value2 == 0 || child3== null)){
             System.err.println("Error MISMATCH BETWEEN VALUES");
             System.exit(-1);
            }
            return false;
        }
    }
    protected boolean isMalformed(){
        if (value1==0){
            return true;
        }
        else{
            if(value2 == 0){
                //two node
                //Interior node
                if(child1 == null && child2 == null && child3 == null){
                    return false;
                }
                else return child1 == null || child2 == null || child3 != null;
            }
            else {
                //three node
                //Interior node
                if(child1 == null && child2 == null && child3 == null){
                    return false;
                }
                else return child1 == null || child2 == null || child3 == null;
            }
        }
    }
    protected TwoThree FourtoThreeTwoNode(){
        if ((value1 == 0 || value2 == 0 || tempValue3 == 0 || isMalformed())){
            System.err.println("Error MISMATCH BETWEEN VALUES");
            System.exit(-1);
        }
        TwoThree subGraphLeft = new TwoThree(value1, child1, child2);
        TwoThree subGraphRight = new TwoThree(tempValue3, child3, tempChild4);
        return new TwoThree(value2, subGraphLeft, subGraphRight);
    }
    protected InnerReturnClass FourNodetoTwoTwoNode(){
        if ((value1 == 0 || value2 == 0 || tempValue3 == 0 || isMalformed())){
            System.err.println("Error MISMATCH BETWEEN VALUES");
            System.exit(-1);
        }
        TwoThree subGraphLeft = new TwoThree(value1, child1, child2);
        TwoThree subGraphRight = new TwoThree(tempValue3, child3, tempChild4);
        InnerReturnClass rtn = new InnerReturnClass();
        rtn.value = value2;
        rtn.left = subGraphLeft;
        rtn.right = subGraphRight;
        return rtn;
    }
    protected class InnerReturnClass{
        public int value;
        public TwoThree left;
        public TwoThree right;
    }
    public TwoThree search(int value, TwoThree node){
        if(node.isTwoNode()){
            return search2(value, node);
        }
        else{
            return search3(value, node);
        }
    }
    public boolean searchContainment(int value, TwoThree rootNode){
        TwoThree node = search(value, rootNode);
        if (node.isTwoNode()){
            return node.value1 == value;
        }
        else{
            return node.value1 == value || node.value2 == value;
        }
    }
    private TwoThree search2(int value, TwoThree node){
        if (node.value1 == value){
            return node;
        }
        else if (value < node.value1){
            if (node.child1 != null){
                return search2(value, node.child1);
            }
            else{
                return node;
            }
        }
        else{
            if (node.child2 != null){
                return search2(value, node.child2);
            }
            else{
                return node;
            }
        }
    }
    private TwoThree search3(int value, TwoThree node){
        if(node.value1 == value){
            return node;
        }
        if(node.value2 == value){
            return node;
        }

        if (value < node.value1){
            if (node.child1 != null){
                return search3(value, node.child1);
            }
            else{
                return node;
            }
        }
        else if (value > node.value2){
            if (node.child3 != null){
                return search3(value, node.child3);
            }
            else{
                return node;
            }
        }
        else{
            if (node.child2 != null){
                return search3(value, node.child2);
            }
            else{
                return node;
            }
        }
    }
    private void split(TwoThree node){
        TwoThree a = new TwoThree(node.value1, node.child1, node.child2);
        TwoThree b = new TwoThree(node.tempValue3, node.child3, node.tempChild4);
        if(node.parent == null){
            root = new TwoThree(node.value2, a, b);
            a.parent = root;
            b.parent = root;
        }
        else if (node.parent.isTwoNode()) {
            TwoThree x = new TwoThree(0, null, null);
            x.parent = node.parent.parent;
            a.parent = x;
            b.parent = x;
            if (node.parent.child2 == node){
                x.child1 = node.parent.child1;
                x.child2 = a;
                x.child3 = b;
                x.value1 = node.parent.value1;
                x.value2 = node.value2;
            }
            else {
                x.child1 = a;
                x.child2 = b;
                x.child3 = node.parent.child2;
                x.value1 = node.value2;
                x.value2 = node.parent.value1;
            }
            node.parent = x;
        }
        else{
            TwoThree x = new TwoThree(0, null, null);
            x.parent = node.parent.parent;
            a.parent = x;
            b.parent = x;
            if(node.parent.child3 == node){
                x.child1 = node.parent.child1;
                x.child2 = node.parent.child2;
                x.child3 = a;
                x.tempChild4 = b;
                x.value1 = node.parent.value1;
                x.value2 = node.parent.value2;
                x.tempValue3 = node.value2;
            }
            else if (node.parent.child1 == node){
                x.tempChild4 = node.parent.child3;
                x.child3 = node.parent.child2;
                x.child2 = b;
                x.child1 = a;
                x.tempValue3 = node.parent.value2;
                x.value2 = node.parent.value1;
                x.value1 = node.value2;
            }
            else{
                x.child1 = node.parent.child1;
                x.child2 = a;
                x.child3 = b;
                x.tempChild4 = node.parent.child3;
                x.value1 = node.parent.value1;
                x.tempValue3 = node.parent.value2;
                x.value2 = node.value2;
            }
            node.parent = x;
            split(x);
        }
    }
    public void insert(int value, TwoThree rootNode){
        if (!searchContainment(value, rootNode)){
            TwoThree node = search(value, rootNode);
            if (node.isTwoNode()){
                if(value > node.value1){
                    node.value2 = value;
                }
                else{
                    node.value2 = node.value1;
                    node.value1 = value;
                }
                split(node);
            }
            else{
                if (value > node.value2){
                    node.tempValue3 = value;
                }
                else if (value < node.value1) {
                    node.tempValue3 = node.value2;
                    node.value2 = node.value1;
                    node.value1 = value;
                }
                else{
                    node.tempValue3 = node.value2;
                    node.value2 = value;
                }
                split(node);
            }
        }
    }
    public int getMax(TwoThree node){
        if (node.isTwoNode()){
            if(node.child2 == null){
                return node.value1;
            }
            else{
                return getMax(node.child2);
            }
        }
        else{
            if (node.child3 == null){
                return node.value2;
            }
            else{
                return getMax(node.child3);
            }
        }
    }

    String inOrder = "";
    public String displayInOrder(TwoThree node){
        if (node == null){
            return"";
        }
        if (isTwoNode()){
            displayInOrder(node.child1);
            inOrder += (node.value1 + ", ");
            displayInOrder(node.child2);
        }
        else{
            displayInOrder(node.child1);
            inOrder += (node.value1 + ", ");
            displayInOrder(node.child2);
            inOrder += (node.value2 + ", ");
            displayInOrder(node.child3);

        }
        return inOrder;
    }
}
